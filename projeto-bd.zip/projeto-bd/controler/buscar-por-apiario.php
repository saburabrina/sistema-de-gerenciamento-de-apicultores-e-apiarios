<?php

	require_once('../model/Usuario.php');
	require_once('../model/Endereco.php');

	session_start();

	function test_input($data) {
	  $data = trim($data);
	  $data = stripslashes($data);
	  $data = htmlspecialchars($data);
	  return $data;
	}

	$nome = $dono = $inscricaoEstadual = $dataFundacao = $latitude = $longitude = $tipoInstalacao = $logradouro = $numero = $complemento = $bairro = $comunidade = $cidade = $estado = $cep = "";

	if ($_SERVER["REQUEST_METHOD"] == "POST") {
	  
	  $nome = test_input($_POST["nome"]);
	  $dono = test_input($_POST["dono"]);
	  $inscricaoEstadual = test_input($_POST["inscricao"]);
	  $dataFundacao = test_input($_POST["data-fundacao"]);
	  $latitude = test_input($_POST["latitude"]);
	  $longitude = test_input($_POST["longitude"]);
	  $tipoInstalacao = test_input($_POST["instalacao"]);
	  //$logradouro = test_input($_POST["logradouro"]);
	  $numero = test_input($_POST["numero"]);
	  $complemento = test_input($_POST["complemento"]);
	  $bairro = test_input($_POST["bairro"]);
	  $comunidade = test_input($_POST["comunidade"]);
	  $cidade = test_input($_POST["cidade"]);
	  $estado = test_input($_POST["estado"]);
	  $cep = test_input($_POST["cep"]);

	  $filtros = array("nome" => $nome, "dono" => $dono, "inscricao_estadual" => $inscricaoEstadual, "data_fundacao" => $dataFundacao, "latitude" => $latitude, "longitude" => $longitude, "tipo_instalacao" => $tipoInstalacao, "logradouro" => $logradouro, "numero" => $numero, "complemento" => $complemento, "bairro" => $bairro, "comunidade" => $comunidade, "cidade" => $cidade, "estado" => $estado, "cep" => $cep);
	
	  $usuario = new Usuario($_SESSION['nome'], $_SESSION['cpf'], $_SESSION['email'], $_SESSION['senha']);
	  $apiarios = $usuario->recuperarApiarios($filtros);

	  $a = array();
	  for($i=0; $i<count($apiarios); $i++){
	  	$apiario = serialize($apiarios[$i]);
	  	array_push($a, $apiario);
	  }

	  $_SESSION['apiarios'] = $a;
	  header('Location: ../views/busca-por-apiario.php');
	}

?>