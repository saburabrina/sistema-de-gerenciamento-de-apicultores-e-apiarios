<?php

	require_once('../model/Usuario.php');

	session_start();

	function test_input($data) {
	  $data = trim($data);
	  $data = stripslashes($data);
	  $data = htmlspecialchars($data);
	  return $data;
	}

	$filtro = $texto = "";

	if ($_SERVER["REQUEST_METHOD"] == "POST") {
	  
	  $filtro = test_input($_POST["filtro"]);
	  $texto = test_input($_POST["texto"]);

	  $usuario = new Usuario($_SESSION['nome'], $_SESSION['cpf'], $_SESSION['email'], $_SESSION['senha']);

	  if($filtro == 'cpf'){
	  	$_SESSION['apicultor'] = $usuario->recuperarApicultorPorAtributo("cpf", $texto);
	  } else {
	  	$_SESSION['apicultor'] = $usuario->recuperarApicultorPorAtributo("nome", $texto);
	  }

	  header('Location: ../views/buscar-apicultor-para-cadastrar-fumegador.php');
	}

?>