<?php

	require_once('../model/Usuario.php');
	require_once('../model/Endereco.php');

	session_start();

	function test_input($data) {
	  $data = trim($data);
	  $data = stripslashes($data);
	  $data = htmlspecialchars($data);
	  return $data;
	}

	$logradouro = $numero = $complemento = $comunidade = $bairro = $cidade = $estado = $cep = "";

	if ($_SERVER["REQUEST_METHOD"] == "POST") {
	  
	  $logradouro = test_input($_POST["logradouro"]);
	  $numero = test_input($_POST["numero"]);
	  $complemento = test_input($_POST["complemento"]);
	  $comunidade = test_input($_POST["comunidade"]);
	  $bairro = test_input($_POST["bairro"]);
	  $cidade = test_input($_POST["cidade"]);
	  $estado = test_input($_POST["estado"]);
	  $cep = test_input($_POST["cep"]);

	  $usuario = new Usuario($_SESSION['nome'], $_SESSION['cpf'], $_SESSION['email'], $_SESSION['senha']);
	  $propriedades = $usuario->recuperarPropriedadesPorEndereco(new Endereco($logradouro, $numero, $complemento, $bairro, $comunidade, $cidade, $estado, $cep));

	  $p = array();
	  for($i=0; $i<count($propriedades); $i++){
	  	$propriedade = serialize($propriedades[$i]);
	  	array_push($p, $propriedade);
	  }

	  $_SESSION['propriedades'] = $p;
	  header('Location: ../views/buscar-propriedade-para-cadastrar-apiario.php');
	}

?>