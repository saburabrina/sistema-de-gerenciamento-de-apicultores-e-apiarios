<?php
	class ControleVeterinario{
		private $id;
		private $apiario;
		private $data_exame;
		private $cond_vet_geral;
        private $nome_vet;
        private $crmv_vet;
        private $tipo_abelha;
        private $material_biologico;
        private $mel;
	}
?>